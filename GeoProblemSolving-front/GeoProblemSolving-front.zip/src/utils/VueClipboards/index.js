import Vue from 'vue'
//引入vue-clipboards组件
import VueClipboards from 'vue-clipboards'
// 使用vue-clipboards
Vue.use(VueClipboards)
export default {
    VueClipboards
}