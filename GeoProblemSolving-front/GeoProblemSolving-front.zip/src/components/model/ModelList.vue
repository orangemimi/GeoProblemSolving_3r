<template>
  <div>
  123
  </div>
</template>

<script>
export default {
  //   components: { Tinymce,tinymceVue },
  data() {
    return {
      pidDisabled: false,
      modelList:[]
    };
  },
  methods: {
   

    // async getAllModel() {      
    //     let data = await this.axios.get(
    //       "/GeoProblemSolving/modelItem/activity",
    //       this.postForm
    //     );
    //     if (data.status == 200) {
    //       this.$Notice.success({
    //         title: "Success",
    //         desc: "Post the model successfully "
    //       });
    //     } else {
    //       this.$Notice.success({
    //         title: "Fail",
    //         desc: "Post the model failed "
    //       });
    //     }
    //     console.log(data);
    //     //   this.openModal = false;
    //     let modalOpen = false; 
    // }
  },
};
</script>
