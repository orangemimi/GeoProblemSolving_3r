
<style>
</style>
<template>
</template>
<script>
export default {
    created(){
        window.location.replace("/GeoProblemSolving/home");
    }
}
</script>